<section class="section section-8">
        <!-- <div class="container" style="height: 100%;"> -->
            <div class="row " style="height: 100%;">
                <div class="col-12 d-flex align-items-center">
                    <div class="col-12  d-flex justify-content-center">
                    <div class="container">

                    <div class="col-12 d-flex justify-content-center">
                        <div class="col-8 row">
                            <div class="col-sm">
                                <img src="wp-content/themes/responsive/css/img/footer-velvet.png" alt="">
                            </div>
                            <div class="col-sm pt-4">
                                <div class="col-12 text-white">
                                    <h4>Email Us:</h4>
                                    <p>info@velvettoke.com</p>
                                    <h5>Follow us on our Social Media:</h5>
                                    <div class="col-12 d-flex justify-content-center">
                                        <img src="wp-content/themes/responsive/css/img/social1.png" alt="">
                                        <img src="wp-content/themes/responsive/css/img/social2.png" alt="">
                                        <img src="wp-content/themes/responsive/css/img/social3.png" alt="">
                                        <img src="wp-content/themes/responsive/css/img/social4.png" alt="">
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm pt-5">
                                <div class="col-12 text-white">
                                    <h4>Call Us:</h4>
                                    <p>(919)338-6079</p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-12 text-center text-white">
                        <p>© 2020 Velvet Toke. All rights reserved · Privacy · Terms · Sitemap</p>
                    </div>
                    </div>
                    </div>
                </div>
            </div>
        <!-- </div> -->
    </section>
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
    <?php wp_footer();?>
</body>
</html>