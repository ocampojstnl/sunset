<?php get_header();?>
<h1>asdsad</h1>
<?php get_footer();?>