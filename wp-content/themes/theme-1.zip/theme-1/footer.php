
<section id="section-8">
        <div class="container">
            <div class="row">
                <div class="col-12 d-flex align-items-center">
                    <div class="col-12  d-flex justify-content-center">
                        <div class="container">
                            <div class="col-12 d-flex justify-content-center">
                                <div class="row">
                                    <div id="velvet-footer" class="col-md">
                                        <img src="wp-content/themes/theme-1/css/img/footer-velvet.png" alt="">
                                    </div>
                                    <div class="col-md">
                                        <div id="contact-details" class="col-12 text-white">
                                            <h4>Email Us:</h4>
                                            <p>info@velvettoke.com</p>
                                            <h5>Follow us on our Social Media:</h5>
                                            <div id="social-media-icons" class="col-12 d-flex justify-content-center">
                                                <img style="margin-left: 0;" src="wp-content/themes/theme-1/css/img/social1.png" alt="">
                                                <img src="wp-content/themes/theme-1/css/img/social2.png" alt="">
                                                <img src="wp-content/themes/theme-1/css/img/social3.png" alt="">
                                                <img src="wp-content/themes/theme-1/css/img/social4.png" alt="">
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md">
                                        <div class="col-12 text-white">
                                            <h4>Call Us:</h4>
                                            <p>(919)338-6079</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-12 text-center text-white">
                                <p id="footer-last-p">© 2020 Velvet Toke. All rights reserved · Privacy · Terms · Sitemap</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
    <?php wp_footer();?>
</body>
</html>